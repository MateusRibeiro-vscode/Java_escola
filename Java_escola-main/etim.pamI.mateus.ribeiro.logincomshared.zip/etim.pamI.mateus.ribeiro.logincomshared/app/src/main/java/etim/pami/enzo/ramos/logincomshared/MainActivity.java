package etim.pami.enzo.ramos.logincomshared;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    EditText nome;
    EditText email;
    EditText senha;
    Button criar , entrar;
    CheckBox lembrar;

    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);
        preferences = getSharedPreferences("Login", 0);
        String pNome =preferences.getString("nome","");
        String pEmail =preferences.getString("Email","");
        String pSEnha =preferences.getString("senha","");


            if (!pNome.isEmpty() && !pEmail.isEmpty() && !pSEnha.isEmpty()){
                Intent intent = new Intent(MainActivity.this,HomeActivity.class);
                startActivity(intent);
            }
            intComponents();


        entrar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (validarDados()) {
                    if (lembrar.isChecked()){
                        preferences  = getSharedPreferences("Login",0);
                        SharedPreferences.Editor dado = preferences.edit();
                        dado.putString("Nome",nome.getText().toString());
                        dado.putString("Email",email.getText().toString());
                        dado.putString("Senha",senha.getText().toString());
                        dado.apply();
                    }
                }
                nome.setText("");
                email.setText("");
                senha.setText("");

                Intent intent = new Intent(MainActivity.this,HomeActivity.class);
                startActivity(intent);
            }});

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            return insets;

        });
    }

    private boolean validarDados() {
        boolean retorno = true;
        if (nome.getText().toString().isEmpty()) {
            retorno = false;
            nome.setError("esse campo nao pode ficar vazio");
            nome.requestFocus();
        }
        if (email.getText().toString().isEmpty()) {
            retorno = false;
            email.setError("esse campo nao pode ficar vazio");
            email.requestFocus();
        }   if (senha.getText().toString().isEmpty()) {
            retorno = false;

        }


        return retorno;
    }


    private void intComponents() {   nome = findViewById(R.id.edt_nome);
        email = findViewById(R.id.edt_email);
        senha = findViewById(R.id.edt_senha);
        entrar = findViewById(R.id.btn_entrar);
        criar = findViewById(R.id.btn_novo);
        lembrar = findViewById(R.id.checkBox);
    }}